package afspc.astrostds.wrappers;

// This exception is thrown when an Astrodynamic Standard dll
// fails to load or initialize successfully.
// author: Joseph C. Lininger, A9YA

public class AstroDllLoadException extends ExceptionInInitializerError
{
   private String dllName;

   public AstroDllLoadException(String n)
   {
      super("Unable to load or initialize " + n);
      dllName = n;
   }

   public String GetDllName()
   {
      return (dllName);
   }
}
