// This wrapper file was generated automatically by the A3\GenDllWrappers program.
package afspc.astrostds.wrappers;
import java.io.*;
import java.io.Reader;
import java.util.Date;
import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Platform;
import com.sun.jna.PointerType;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.DoubleByReference;
import afspc.astrostds.utilities.Utility;



public class JnaTle
{
   // Provide the path to the dll/so
   // **************************************************************************
   // On Unix/Linux platforms: please RENAME the provided shared object (SO) from "Tle.dll" to "libTle.so"
   // **************************************************************************
   public static final String dllName = "Tle";

   static
   {
      JnaTimeFunc.Init();
      Native.register(dllName);
      if (TleInit(JnaDllMain.ApPtr) != 0)
      {
         throw new AstroDllLoadException(dllName);
      }
   }

   /**
   * Dummy function, used to make sure dependencies are satisfied
   */
   public static void Init()
   { }


   /**
   * Initializes Tle DLL for use in the program.
   * @param apPtr The handle that was returned from DllMainInit. See the documentation for DllMain.dll for details.
   * @return 0 if Tle.dll is initialized successfully, non-0 if there is an error.
   */
   public static native int TleInit(long apPtr);


   /**
   * Returns the information about the Tle DLL.
   * @param infoStr A string to hold the information about the Tle DLL.
   */
   public static native void TleGetInfo(byte[] infoStr);


   /**
   * Loads TLEs (satellites) contained in a text file into the TLE DLL's binary tree.
   * @param tleFile The name of the file containing two line element sets to be loaded.
   * @return 0 if the two line element sets in the file are successfully loaded, non-0 if there is an error.
   */
   public static native int TleLoadFile(String tleFile);


   /**
   * Saves currently loaded TLEs to a file. 
   * @param tleFile The name of the file in which to save the TLE's.
   * @param saveMode Specifies whether to create a new file or append to an existing file. (0 = create new file, 1= append to existing file)
   * @param saveForm Specifies the format in which to save the file. (0 = two-line element set format, 2 = XML format (future implementation))
   * @return 0 if the data is successfully saved to the file, non-0 if there is an error.
   */
   public static native int TleSaveFile(String tleFile, int saveMode, int saveForm);


   /**
   * Removes a TLE represented by the satKey from memory. 
   * @param satKey The unique key of the satellite to be removed.
   * @return 0 if the TLE is removed successfully, non-0 if there is an error.
   */
   public static native int TleRemoveSat(long satKey);


   /**
   * Removes all the TLEs from memory.
   * @return 0 if all TLE's are removed successfully from memory, non-0 if there is an error.
   */
   public static native int TleRemoveAllSats();


   /**
   * Returns the number of TLEs currently loaded. 
   * @return The number of TLEs currently loaded.
   */
   public static native int TleGetCount();


   /**
   * Retrieves all of the currently loaded satKeys. These satKeys can be used to access the internal data for the TLE's.
   * @param order Specifies the order in which the satKeys should be returned. 0 = sort in ascending order of satKeys, 1 = sort in descending order of satKeys, 2 = sort in the order in which the satKeys were loaded in memory, 9 = Quickest: sort in the order in which the satKeys were stored in the tree
   * @param satKeys The array in which to store the satKeys.
   */
   public static native void TleGetLoaded(int order, long[] satKeys);


   /**
   * Adds a TLE (satellite), using its directly specified first and second lines. 
   * @param line1 The first line of a two line element set.
   * @param line2 The second line of a two line element set.
   * @return The satKey of the newly added TLE on success, a negative value on error.
   */
   public static native long TleAddSatFrLines(String line1, String line2);


   /**
   * This function is similar to TleAddSatFrLines but designed to be used in Matlab.
   * @param line1 The first line of a two line element set.
   * @param line2 The second line of a two line element set.
   * @param satKey The satKey of the newly added TLE on success, a negative value on error.
   */
   public static native void TleAddSatFrLinesML(String line1, String line2, LongByReference satKey);


   /**
   * Adds a GP TLE using its individually provided field values. 
   * @param satNum Satellite number
   * @param secClass Security classification
   * @param satName Satellite international designator
   * @param epochYr Element epoch time - year, [YY]YY
   * @param epochDays Element epoch time - day of year, DDD.DDDDDDDD
   * @param bstar B* drag term (1/er)
   * @param ephType Satellite ephemeris type (0: SGP, 2: SGP4)
   * @param elsetNum Element set number
   * @param incli Orbit inclination (degrees)
   * @param node Right ascension of ascending node (degrees)
   * @param eccen Eccentricity
   * @param omega Argument of perigee (degrees)
   * @param mnAnomaly Mean anomaly (degrees)
   * @param mnMotion Mean motion (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
   * @param revNum Revolution number at epoch
   * @return The satKey of the newly added TLE on success, a negative value on error.
   */
   public static native long TleAddSatFrFieldsGP(int satNum, char secClass, String satName, int epochYr, double epochDays, double bstar, int ephType, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum);


   /**
   * This function is similar to TleAddSatFrFieldsGP but includes nDotO2 and n2DotO6. 
   * @param satNum Satellite number
   * @param secClass Security classification
   * @param satName Satellite international designator
   * @param epochYr Element epoch time - year, [YY]YY
   * @param epochDays Element epoch time - day of year, DDD.DDDDDDDD
   * @param bstar B* drag term (1/er)
   * @param ephType Satellite ephemeris type (0: SGP, 2: SGP4)
   * @param elsetNum Element set number
   * @param incli Orbit inclination (degrees)
   * @param node Right ascension of ascending node (degrees)
   * @param eccen Eccentricity
   * @param omega Argument of perigee (degrees)
   * @param mnAnomaly Mean anomaly (degrees)
   * @param mnMotion Mean motion (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
   * @param revNum Revolution number at epoch
   * @param nDotO2 Mean motion derivative (rev/day /2)
   * @param n2DotO6 Mean motion second derivative (rev/day**2 /6)
   * @return The satKey of the newly added TLE on success, a negative value on error.
   */
   public static native long TleAddSatFrFieldsGP2(int satNum, char secClass, String satName, int epochYr, double epochDays, double bstar, int ephType, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum, double nDotO2, double n2DotO6);


   /**
   * This function is similar to TleAddSatFrFieldsGP2 but designed to be used in Matlab. 
   * @param satNum Satellite number
   * @param secClass Security classification
   * @param satName Satellite international designator
   * @param epochYr Element epoch time - year, [YY]YY
   * @param epochDays Element epoch time - day of year, DDD.DDDDDDDD
   * @param bstar B* drag term (1/er)
   * @param ephType Satellite ephemeris type (0: SGP, 2: SGP4)
   * @param elsetNum Element set number
   * @param incli Orbit inclination (degrees)
   * @param node Right ascension of ascending node (degrees)
   * @param eccen Eccentricity
   * @param omega Argument of perigee (degrees)
   * @param mnAnomaly Mean anomaly (degrees)
   * @param mnMotion Mean motion (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
   * @param revNum Revolution number at epoch
   * @param nDotO2 Mean motion derivative (rev/day /2)
   * @param n2DotO6 Mean motion second derivative (rev/day**2 /6)
   * @param satKey The satKey of the newly added TLE on success, a negative value on error.
   */
   public static native void TleAddSatFrFieldsGP2ML(int satNum, char secClass, String satName, int epochYr, double epochDays, double bstar, int ephType, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum, double nDotO2, double n2DotO6, LongByReference satKey);


   /**
   * Updates a GP satellite's data in memory by providing its individual field values. 
   * @param satKey The satellite's unique key
   * @param secClass Security classification
   * @param satName Satellite international designator
   * @param bstar B* drag term (1/er)
   * @param elsetNum Element set number
   * @param incli Orbit inclination (degrees)
   * @param node Right ascension of ascending node (degrees)
   * @param eccen Eccentricity
   * @param omega Argument of perigee (degrees)
   * @param mnAnomaly Mean anomaly (degrees)
   * @param mnMotion Mean motion  (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
   * @param revNum Revolution number at epoch
   * @return 0 if the TLE is successfully updated, non-0 if there is an error.
   */
   public static native int TleUpdateSatFrFieldsGP(long satKey, char secClass, String satName, double bstar, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum);


   /**
   * This function is similar to TleUpdateSatFrFieldsGP but includes nDotO2 and n2DotO6.
   * @param satKey The satellite's unique key
   * @param secClass Security classification
   * @param satName Satellite international designator
   * @param bstar B* drag term (1/er)
   * @param elsetNum Element set number
   * @param incli Orbit inclination (degrees)
   * @param node Right ascension of ascending node (degrees)
   * @param eccen Eccentricity
   * @param omega Argument of perigee (degrees)
   * @param mnAnomaly Mean anomaly (degrees)
   * @param mnMotion Mean motion  (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
   * @param revNum Revolution number at epoch
   * @param nDotO2 Mean motion derivative (rev/day /2)
   * @param n2DotO6 Mean motion second derivative (rev/day**2 /6)
   * @return 0 if the TLE is successfully updated, non-0 if there is an error.
   */
   public static native int TleUpdateSatFrFieldsGP2(long satKey, char secClass, String satName, double bstar, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum, double nDotO2, double n2DotO6);


   /**
   * Adds an SP satellite using the individually provided field values.
   * @param satNum Satellite number
   * @param secClass Security classification
   * @param satName Satellite international designator
   * @param epochYr Element epoch time - year, [YY]YY
   * @param epochDays Element epoch time - day of year, DDD.DDDDDDDD
   * @param bTerm Ballistic coefficient (m^2/kg)
   * @param ogParm Outgassing parameter/Thrust Acceleration (km/s^2)
   * @param agom Agom (m^2/kg)
   * @param elsetNum Element set number
   * @param incli Orbit inclination (degrees)
   * @param node Right ascension of ascending node (degrees)
   * @param eccen Eccentricity
   * @param omega Argument of perigee (degrees)
   * @param mnAnomaly Mean anomaly (degrees)
   * @param mnMotion Mean motion (rev/day)
   * @param revNum Revolution number at epoch
   * @return The satKey of the newly added TLE on success, a negative value on error.
   */
   public static native long TleAddSatFrFieldsSP(int satNum, char secClass, String satName, int epochYr, double epochDays, double bTerm, double ogParm, double agom, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum);


   /**
   * This function is similar to TleAddSatFrFieldsSP but designed to be used in Matlab.
   * @param satNum Satellite number
   * @param secClass Security classification
   * @param satName Satellite international designator
   * @param epochYr Element epoch time - year, [YY]YY
   * @param epochDays Element epoch time - day of year, DDD.DDDDDDDD
   * @param bTerm Ballistic coefficient (m^2/kg)
   * @param ogParm Outgassing parameter/Thrust Acceleration (km/s^2)
   * @param agom Agom (m^2/kg)
   * @param elsetNum Element set number
   * @param incli Orbit inclination (degrees)
   * @param node Right ascension of ascending node (degrees)
   * @param eccen Eccentricity
   * @param omega Argument of perigee (degrees)
   * @param mnAnomaly Mean anomaly (degrees)
   * @param mnMotion Mean motion (rev/day)
   * @param revNum Revolution number at epoch
   * @param satKey The satKey of the newly added TLE on success, a negative value on error.
   */
   public static native void TleAddSatFrFieldsSPML(int satNum, char secClass, String satName, int epochYr, double epochDays, double bTerm, double ogParm, double agom, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum, LongByReference satKey);


   /**
   * Updates an SP satellite's data in memory using its individually provided field values.
   * @param satKey The satellite's unique key
   * @param secClass Security classification
   * @param satName Satellite international designator
   * @param bterm Ballistic coefficient (m^2/kg)
   * @param ogParm Outgassing parameter/Thrust Acceleration (km/s^2)
   * @param agom Agom (m^2/kg)
   * @param elsetNum Element set number
   * @param incli Orbit inclination (degrees)
   * @param node Right ascension of ascending node (degrees)
   * @param eccen Eccentricity
   * @param omega Argument of perigee (degrees)
   * @param mnAnomaly Mean anomaly (degrees)
   * @param mnMotion Mean motion (rev/day)
   * @param revNum Revolution number at epoch
   * @return 0 if the TLE is successfully updated, non-0 if there is an error.
   */
   public static native int TleUpdateSatFrFieldsSP(long satKey, char secClass, String satName, double bterm, double ogParm, double agom, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum);


   /**
   * Updates the value of a field of a TLE. This function can be used for both GP and SP satellites.
   * @param satKey The satellite's unique key.
   * @param xf_Tle Predefined number specifying which field to set. See remarks.
   * @param valueStr The new value of the specified field, expressed as a string.
   * @return 0 if the TLE is successfully updated, non-0 if there is an error
   */
   public static native int TleSetField(long satKey, int xf_Tle, String valueStr);


   /**
   * Retrieves the value of a specific field of a TLE. 
   * @param satKey The satellite's unique key.
   * @param xf_Tle Predefined number specifying which field to retrieve. See remarks.
   * @param valueStr A string to contain the value of the requested field.
   * @return 0 if the TLE data is successfully retrieved, non-0 if there is an error.
   */
   public static native int TleGetField(long satKey, int xf_Tle, byte[] valueStr);


   /**
   * Retrieves all of the data for a GP satellite in a single function call. 
   * @param satKey The satellite's unique key
   * @param satNum Satellite number
   * @param secClass Security classification
   * @param satName Satellite international designator
   * @param epochYr Element epoch time - year, [YY]YY
   * @param epochDays Element epoch time - day of year, DDD.DDDDDDDD
   * @param bstar B* drag term (1/er)
   * @param ephType Satellite ephemeris type (0: SGP, 2: SGP4, 6: SP)
   * @param elsetNum Element set number
   * @param incli Orbit inclination (degrees)
   * @param node Right ascension of ascending node (degrees)
   * @param eccen Eccentricity
   * @param omega Argument of perigee (degrees)
   * @param mnAnomaly Mean anomaly (deg)
   * @param mnMotion Mean motion (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
   * @param revNum Revolution number at epoch
   * @return 0 if all values are retrieved successfully, non-0 if there is an error.
   */
   public static native int TleGetAllFieldsGP(long satKey, IntByReference satNum, ByteByReference secClass, byte[] satName, IntByReference epochYr, DoubleByReference epochDays, DoubleByReference bstar, IntByReference ephType, IntByReference elsetNum, DoubleByReference incli, DoubleByReference node, DoubleByReference eccen, DoubleByReference omega, DoubleByReference mnAnomaly, DoubleByReference mnMotion, IntByReference revNum);


   /**
   * Retrieves all of the data (including nDotO2 and n2DotO6) for a GP satellite in a single function call. 
   * @param satKey The satellite's unique key
   * @param satNum Satellite number
   * @param secClass Security classification
   * @param satName Satellite international designator
   * @param epochYr Element epoch time - year, [YY]YY
   * @param epochDays Element epoch time - day of year, DDD.DDDDDDDD
   * @param bstar B* drag term (1/er)
   * @param ephType Satellite ephemeris type (0: SGP, 2: SGP4, 6: SP)
   * @param elsetNum Element set number
   * @param incli Orbit inclination (degrees)
   * @param node Right ascension of ascending node (degrees)
   * @param eccen Eccentricity
   * @param omega Argument of perigee (degrees)
   * @param mnAnomaly Mean anomaly (degrees)
   * @param mnMotion Mean motion (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
   * @param revNum Revolution number at epoch
   * @param nDotO2 Mean motion derivative (rev/day /2)
   * @param n2DotO6 Mean motion second derivative (rev/day**2 /6)
   * @return 0 if all values are retrieved successfully, non-0 if there is an error.
   */
   public static native int TleGetAllFieldsGP2(long satKey, IntByReference satNum, ByteByReference secClass, byte[] satName, IntByReference epochYr, DoubleByReference epochDays, DoubleByReference bstar, IntByReference ephType, IntByReference elsetNum, DoubleByReference incli, DoubleByReference node, DoubleByReference eccen, DoubleByReference omega, DoubleByReference mnAnomaly, DoubleByReference mnMotion, IntByReference revNum, DoubleByReference nDotO2, DoubleByReference n2DotO6);


   /**
   * Retrieves all of the data for an SP satellite in a single function call.
   * @param satKey The satellite's unique key
   * @param satNum Satellite number
   * @param secClass Security classification
   * @param satName Satellite international designator
   * @param epochYr Element epoch time - year, [YY]YY
   * @param epochDays Element epoch time - day of year, DDD.DDDDDDDD
   * @param bTerm Ballistic coefficient (m^2/kg)
   * @param ogParm Outgassing parameter/Thrust Acceleration (km/s^2)
   * @param agom Agom (m^2/kg)
   * @param elsetNum Element set number
   * @param incli Orbit inclination (degrees)
   * @param node Right ascension of ascending node (degrees)
   * @param eccen Eccentricity
   * @param omega Argument of perigee (degrees)
   * @param mnAnomaly Mean anomaly (degrees)
   * @param mnMotion Mean motion (rev/day)
   * @param revNum Revolution number at epoch
   * @return 0 if all values are retrieved successfully, non-0 if there is an error.
   */
   public static native int TleGetAllFieldsSP(long satKey, IntByReference satNum, ByteByReference secClass, byte[] satName, IntByReference epochYr, DoubleByReference epochDays, DoubleByReference bTerm, DoubleByReference ogParm, DoubleByReference agom, IntByReference elsetNum, DoubleByReference incli, DoubleByReference node, DoubleByReference eccen, DoubleByReference omega, DoubleByReference mnAnomaly, DoubleByReference mnMotion, IntByReference revNum);


   /**
   * Parses GP data from the input first and second lines of a two line element set.
   * @param line1 The first line of the two line element set.
   * @param line2 The second line of the two line element set.
   * @param satNum Satellite number
   * @param secClass Security classification
   * @param satName Satellite international designator
   * @param epochYr Element epoch time - year, [YY]YY
   * @param epochDays Element epoch time - day of year, DDD.DDDDDDDD
   * @param nDotO2 n-dot/2 (for SGP, ephType = 0)
   * @param n2DotO6 n-double-dot/6 (for SGP, ephType = 0)
   * @param bstar B* drag term (1/er)
   * @param ephType Satellite ephemeris type (0: SGP, 2: SGP4, 6: SP)
   * @param elsetNum Element set number
   * @param incli Orbit inclination (degrees)
   * @param node Right ascension of ascending node (degrees).
   * @param eccen Eccentricity
   * @param omega Argument of perigee (degrees)
   * @param mnAnomaly Mean anomaly (degrees)
   * @param mnMotion Mean motion (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
   * @param revNum Revolution number at epoch
   * @return 0 if the TLE is parsed successfully, non-0 if there is an error.
   */
   public static native int TleParseGP(String line1, String line2, IntByReference satNum, ByteByReference secClass, byte[] satName, IntByReference epochYr, DoubleByReference epochDays, DoubleByReference nDotO2, DoubleByReference n2DotO6, DoubleByReference bstar, IntByReference ephType, IntByReference elsetNum, DoubleByReference incli, DoubleByReference node, DoubleByReference eccen, DoubleByReference omega, DoubleByReference mnAnomaly, DoubleByReference mnMotion, IntByReference revNum);


   /**
   * Parses SP data from the input first and second lines of a two line element set.
   * @param line1 The first line of the two line element set.
   * @param line2 The second line of the two line element set.
   * @param satNum Satellite number
   * @param secClass Security classification
   * @param satName Satellite international designator
   * @param epochYr Element epoch time - year, [YY]YY
   * @param epochDays Element epoch time - day of year, DDD.DDDDDDDD
   * @param bTerm Ballistic coefficient (m^2/kg).
   * @param ogParm Outgassing parameter/Thrust Acceleration (km/s^2)
   * @param agom Agom (m^2/kg)
   * @param elsetNum Element set number
   * @param incli Orbit inclination (degrees)
   * @param node Right ascension of ascending node (degrees)
   * @param eccen Eccentricity
   * @param omega Argument of perigee (degrees)
   * @param mnAnomaly Mean anomaly (degrees)
   * @param mnMotion Mean motion (rev/day)
   * @param revNum Revolution number at epoch
   * @return 0 if the TLE is parsed successfully, non-0 if there is an error.
   */
   public static native int TleParseSP(String line1, String line2, IntByReference satNum, ByteByReference secClass, byte[] satName, IntByReference epochYr, DoubleByReference epochDays, DoubleByReference bTerm, DoubleByReference ogParm, DoubleByReference agom, IntByReference elsetNum, DoubleByReference incli, DoubleByReference node, DoubleByReference eccen, DoubleByReference omega, DoubleByReference mnAnomaly, DoubleByReference mnMotion, IntByReference revNum);


   /**
   * Returns the first and second lines representation of a TLE of a satellite. 
   * @param satKey The satellite's unique key.
   * @param line1 A string to hold the first line of the TLE.
   * @param line2 A string to hold the second line of the TLE.
   * @return 0 if successful, non-0 on error.
   */
   public static native int TleGetLines(long satKey, byte[] line1, byte[] line2);


   /**
   * Constructs a TLE from individually provided GP data fields.
   * @param satNum Satellite number
   * @param secClass Security classification
   * @param satName Satellite international designator
   * @param epochYr Element epoch time - year, [YY]YY
   * @param epochDays Element epoch time - day of year, DDD.DDDDDDDD
   * @param nDotO2 N Dot/2 (rev/day /2)
   * @param n2DotO6 N Double Dot/6 (rev/day**2 /6)
   * @param bstar B* drag term (1/er)
   * @param ephType Satellite ephemeris type (0: SGP, 2: SGP4)
   * @param elsetNum Element set number
   * @param incli Orbit inclination (degrees)
   * @param node Right ascension of ascending node (degrees)
   * @param eccen Eccentricity
   * @param omega Argument of perigee (degrees)
   * @param mnAnomaly Mean anomaly (degrees)
   * @param mnMotion Mean motion (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
   * @param revNum Revolution number at epoch
   * @param line1 Returned first line of a TLE.
   * @param line2 Returned second line of a TLE.
   */
   public static native void TleGPFieldsToLines(int satNum, char secClass, String satName, int epochYr, double epochDays, double nDotO2, double n2DotO6, double bstar, int ephType, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum, byte[] line1, byte[] line2);


   /**
   * Constructs a TLE from individually provided SP data fields.
   * @param satNum Satellite number
   * @param secClass Security classification
   * @param satName Satellite international designator
   * @param epochYr Element epoch time - year, [YY]YY
   * @param epochDays Element epoch time - day of year, DDD.DDDDDDDD
   * @param bTerm Ballistic coefficient (m^2/kg)
   * @param ogParm Outgassing parameter/Thrust Acceleration (km/s^2)
   * @param agom Agom (m^2/kg)
   * @param elsetNum Element set number
   * @param incli Orbit inclination (degrees)
   * @param node Right ascension of ascending node (degrees)
   * @param eccen Eccentricity
   * @param omega Argument of perigee (degrees)
   * @param mnAnomaly Mean anomaly (degrees)
   * @param mnMotion Mean motion (rev/day)
   * @param revNum Revolution number at epoch
   * @param line1 Returned first line of a TLE.
   * @param line2 Returned second line of a TLE.
   */
   public static native void TleSPFieldsToLines(int satNum, char secClass, String satName, int epochYr, double epochDays, double bTerm, double ogParm, double agom, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum, byte[] line1, byte[] line2);


   /**
   * Returns the first satKey from the currently loaded set of TLEs that contains the specified satellite number.
   * @param satNum Satellite number
   * @return The satellite's unique key
   */
   public static native long TleGetSatKey(int satNum);


   /**
   * This function is similar to TleGetSatKey but designed to be used in Matlab. 
   * @param satNum Satellite number
   * @param satKey The satKey of the satellite if a satellite with the requested number is found in the set of loaded satellites, a negative value if there is an error.
   */
   public static native void TleGetSatKeyML(int satNum, LongByReference satKey);


   /**
   * Computes a satKey from the input data.
   * @param satNum Satellite number
   * @param epochYr Element epoch time - year, [YY]YY
   * @param epochDays Element epoch time - day of year, DDD.DDDDDDDD
   * @param ephType Ephemeris type
   * @return The resulting satellite key if the computation is successful; a negative value if there is an error.
   */
   public static native long TleFieldsToSatKey(int satNum, int epochYr, double epochDays, int ephType);


   /**
   * This function is similar to TleFieldsToSatKey but designed to be used in Matlab. 
   * @param satNum Satellite number
   * @param epochYr Element epoch time - year, [YY]YY
   * @param epochDays Element epoch time - day of year, DDD.DDDDDDDD
   * @param ephType Ephemeris type
   * @param satKey The satKey if the computation is successful, a negative value if there is an error.
   */
   public static native void TleFieldsToSatKeyML(int satNum, int epochYr, double epochDays, int ephType, LongByReference satKey);
     
   // Indexes of TLE data fields
   public static final int  
      XF_TLE_SATNUM     =  1,    // Satellite number
      XF_TLE_CLASS      =  2,    // Security classification U: unclass, C: confidential, S: Secret
      XF_TLE_SATNAME    =  3,    // Satellite name A8
      XF_TLE_EPOCH      =  4,    // Satellite's epoch time "YYYYJJJ.jjjjjjjj"
      XF_TLE_BSTAR      =  5,    // GP B* drag term (1/er)  
      XF_TLE_SP_AGOM    =  5,    // SP Radiation Pressure Coefficient
      XF_TLE_EPHTYPE    =  6,    // Satellite ephemeris type: 0=SGP, 2=SGP4, 6=SP
      XF_TLE_ELSETNUM   =  7,    // Element set number
      XF_TLE_INCLI      =  8,    // Orbit inclination (deg)
      XF_TLE_NODE       =  9,    // Right ascension of asending node (deg)
      XF_TLE_ECCEN      = 10,    // Eccentricity
      XF_TLE_OMEGA      = 11,    // Argument of perigee (deg)
      XF_TLE_MNANOM     = 12,    // Mean anomaly (deg)
      XF_TLE_MNMOTN     = 13,    // Mean motion (rev/day) (ephType=0: Kozai, ephType=2: Brouwer)
      XF_TLE_REVNUM     = 14,    // Revolution number at epoch 
      
      XF_TLE_NDOT       = 15,    // GP Mean motion derivative (rev/day /2)
      XF_TLE_NDOTDOT    = 16,    // GP Mean motion second derivative (rev/day**2 /6)
   
      XF_TLE_SP_BTERM   = 15,    // SP ballistic coefficient (m2/kg)
      XF_TLE_SP_OGPARM  = 16;    // SP outgassing parameter (km/s2)
   
   
// ========================= End of auto generated code ==========================
}
