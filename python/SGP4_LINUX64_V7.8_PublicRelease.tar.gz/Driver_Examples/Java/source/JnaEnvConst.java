// This wrapper file was generated automatically by the A3\GenDllWrappers program.
package afspc.astrostds.wrappers;
import java.io.*;
import java.io.Reader;
import java.util.Date;
import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Platform;
import com.sun.jna.PointerType;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.DoubleByReference;
import afspc.astrostds.utilities.Utility;



public class JnaEnvConst
{
   // Provide the path to the dll/so
   // **************************************************************************
   // On Unix/Linux platforms: please RENAME the provided shared object (SO) from "EnvConst.dll" to "libEnvConst.so"
   // **************************************************************************
   public static final String dllName = "EnvConst";

   static
   {
      Native.register(dllName);
      if (EnvInit(JnaDllMain.ApPtr) != 0)
      {
         throw new AstroDllLoadException(dllName);
      }
   }

   /**
   * Dummy function, used to make sure dependencies are satisfied
   */
   public static void Init()
   { }


   /**
   * Initializes the EnvInit DLL for use in the program.
   * @param apPtr The handle that was returned from DllMainInit, see the documentation for DllMain.dll for details.
   * @return Returns zero indicating the EnvConst DLL has been initialized successfully. Other values indicate an error.
   */
   public static native int EnvInit(long apPtr);


   /**
   * Returns information about the EnvConst DLL.
   * @param infoStr A string to hold the information about EnvConst.dll.
   */
   public static native void EnvGetInfo(byte[] infoStr);


   /**
   * Reads Earth constants (GEO) model and fundamental catalogue (FK) model settings from a file.
   * @param envFile The name of the input file.
   * @return Returns zero indicating the input file has been loaded successfully. Other values indicate an error.
   */
   public static native int EnvLoadFile(String envFile);


   /**
   * Saves the current Earth constants (GEO) model and fundamental catalogue (FK) model settings to a file.
   * @param envConstFile The name of the file in which to save the settings.
   * @param saveMode Specifies whether to create a new file or append to an existing one. (0 = create, 1= append)
   * @param saveForm Specifies the mode in which to save the file. (0 = text format, 1 = xml (not yet implemented, reserved for future))
   * @return Returns zero indicating the GEO and FK settings have been successfully saved to the file. Other values indicate an error.
   */
   public static native int EnvSaveFile(String envConstFile, int saveMode, int saveForm);


   /**
   * Returns the current fundamental catalogue (FK) setting. 
   * @return Return the current FK setting as an integer. Valid values are: (4 = FK4, 5 = FK5)
   */
   public static native int EnvGetFkIdx();


   /**
   * Changes the fundamental catalogue (FK) setting to the specified value. 
   * @param xf_FkMod Specifies the FK model to use. The following values are accepted: xf_FkMod= 4: FK4, xf_FkMod= 5: FK5
   */
   public static native void EnvSetFkIdx(int xf_FkMod);


   /**
   * Returns the current Earth constants (GEO) setting. 
   * @return The current GEO setting, expressed as an integer.
   */
   public static native int EnvGetGeoIdx();


   /**
   * Changes the Earth constants (GEO) setting to the specified value.
   * @param xf_GeoMod Specifies the GEO model to use.
   */
   public static native void EnvSetGeoIdx(int xf_GeoMod);


   /**
   * Returns the name of the current Earth constants (GEO) model. 
   * @param geoStr A string to store the name of the current GEO model.
   */
   public static native void EnvGetGeoStr(byte[] geoStr);


   /**
   * Changes the Earth constants (GEO) setting to the model specified by a string literal. 
   * @param geoStr The GEO model to use, expressed as a string.
   */
   public static native void EnvSetGeoStr(String geoStr);


   /**
   * Retrieves the value of one of the constants from the current Earth constants (GEO) model. 
   * @param xf_GeoCon An index specifying the constant you wish to retrieve, see XF_GEOCON_? for field specification
   * @return Value of the requested GEO constant
   */
   public static native double EnvGetGeoConst(int xf_GeoCon);


   /**
   * Retrieves the value of one of the constants from the current fundamental catalogue (FK) model.
   * @param xf_FkCon An index specifying the constant you wish to retrieve, , see XF_FKCON_? for field specification
   * @return Value of the requested FK constant
   */
   public static native double EnvGetFkConst(int xf_FkCon);


   /**
   * Returns a handle that can be used to access the fundamental catalogue (FK) data structure. 
   * @return A handle which can be used to access the FK data structure.
   */
   public static native long EnvGetFkPtr();
   
   // Indexes of Earth Constant fields
   public static final int     
      XF_GEOCON_FF    = 1,         // Earth flattening (reciprocal; unitless)
      XF_GEOCON_J2    = 2,         // J2 (unitless)
      XF_GEOCON_J3    = 3,         // J3 (unitless)
      XF_GEOCON_J4    = 4,         // J4 (unitless)
      XF_GEOCON_KE    = 5,         // Ke (er**1.5/min)
      XF_GEOCON_KMPER = 6,         // Earth radius (km/er)
      XF_GEOCON_RPTIM = 7,         // Earth rotation rate w.r.t. fixed equinox (rad/min)
   
      XF_GEOCON_CK2   = 8,         // J2/2 (unitless)
      XF_GEOCON_CK4   = 9,         // -3/8 J4 (unitless)
      XF_GEOCON_KS2EK = 10,        // Converts km/sec to er/kem
      XF_GEOCON_THDOT = 11;        // Earth rotation rate w.r.t. fixed equinox (rad/kemin)
      
   
   // Indexes of FK Constant fields
   public static final int                     
      XF_FKCON_C1     = 1,         // Earth rotation rate w.r.t. moving equinox (rad/day) 
      XF_FKCON_C1DOT  = 2,         // Earth rotation acceleration(rad/day**2) 
      XF_FKCON_THGR70 = 3;         // Greenwich angle (1970; rad) 
   
   // Indexes represent geopotential models GEO
   public static final int  
      XF_GEOMOD_WGS84  = 84,     // Earth constants - WGS-84
      XF_GEOMOD_EGM96  = 96,     // Earth constants - EGM-96
      XF_GEOMOD_WGS72  = 72,     // Earth constants - WGS-72
      XF_GEOMOD_JGM2   =  2,     // Earth constants - JGM2
      XF_GEOMOD_STEM68 = 68,     // Earth constants - STEM68
      XF_GEOMOD_GEM5   =  5,     // Earth constants - GEM5
      XF_GEOMOD_GEM9   =  9,     // Earth constants - GEM9
      XF_GEOMOD_UNKNOWN= 100;
   
   //*******************************************************************************
   
   // Indexes represent fundamental catalogue FK
   public static final int  
      XF_FKMOD_4 = 4,    // Fundamental Catalog - FK5
      XF_FKMOD_5 = 5;    // Fundamental Catalog - FK4
   
   
// ========================= End of auto generated code ==========================
}
