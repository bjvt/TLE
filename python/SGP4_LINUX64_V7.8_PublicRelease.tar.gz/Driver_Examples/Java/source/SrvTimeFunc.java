package afspc.astrostds.services;
import java.io.*;
import java.io.Reader;
import java.util.Date;
import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Platform;
import com.sun.jna.PointerType;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.DoubleByReference;
import afspc.astrostds.wrappers.JnaTimeFunc;
import afspc.astrostds.utilities.Utility;



public class SrvTimeFunc
{
   // <JCL> Convert DS50 to YYYY/DDD HHMM SS.SSS, expressed as a string
   public static String UTCToDtg20Str(double ds50UTC)
   {
      byte [] dtg20 = new byte[20];
      JnaTimeFunc.UTCToDTG20(ds50UTC, dtg20);
      return Utility.BytesToString(dtg20);
   }

   // <JCL> Convert DS50 to YYYY/DDD HHMM SS.SSS, expressed as a string
   public static String UTCToDtg18Str(double ds50UTC)
   {
      byte [] dtg20 = new byte[20];
      JnaTimeFunc.UTCToDTG20(ds50UTC, dtg20);
      return (Utility.BytesToString(dtg20).substring(2));
   }
     
}
