// This wrapper file was generated automatically by the A3\GenDllWrappers program.
package afspc.astrostds.wrappers;
import java.io.*;
import java.io.Reader;
import java.util.Date;
import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Platform;
import com.sun.jna.PointerType;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.DoubleByReference;
import afspc.astrostds.utilities.Utility;



public class JnaAstroFunc
{
   // Provide the path to the dll/so
   // **************************************************************************
   // On Unix/Linux platforms: please RENAME the provided shared object (SO) from "AstroFunc.dll" to "libAstroFunc.so"
   // **************************************************************************
   public static final String dllName = "AstroFunc";

   static
   {
      JnaEnvConst.Init();
      Native.register(dllName);
      if (AstroFuncInit(JnaDllMain.ApPtr) != 0)
      {
         throw new AstroDllLoadException(dllName);
      }
   }

   /**
   * Dummy function, used to make sure dependencies are satisfied
   */
   public static void Init()
   { }


   /**
   * Initializes AstroFunc DLL for use in the program.
   * @param apPtr The handle that was returned from DllMainInit(). See the documentation for DllMain.dll for details.
   * @return 0 if AstroFunc.dll is initialized successfully, non-0 if there is an error.
   */
   public static native int AstroFuncInit(long apPtr);


   /**
   * Retrieves information about the current version of AstroFunc.dll. The information is placed in the string parameter you pass in.
   * @param infoStr A string to hold the information about AstroFunc.dll.
   */
   public static native void AstroFuncGetInfo(byte[] infoStr);


   /**
   * Converts a set of Keplerian elements to a set of equinoctial elements. 
   * @param metricKep The set of Keplerian elements to be converted.
   * @param metricEqnx The resulting set of equinoctial elements.
   */
   public static native void KepToEqnx(double[] metricKep, double[] metricEqnx);


   /**
   * Converts a set of Keplerian elements to position and velocity vectors.
   * @param metricKep The set of Keplerian elements to be converted.
   * @param pos The resulting position vector.
   * @param vel The resulting velocity vector.
   */
   public static native void KepToPosVel(double[] metricKep, double[] pos, double[] vel);


   /**
   * Converts a set of Keplerian elements to Ubar, Vbar, and Wbar vectors.
   * @param metricKep The set of Keplerian elements to be converted.
   * @param uBar The resulting ubar vector.
   * @param vBar The resulting vbar vector.
   * @param wBar The resulting wbar vector.
   */
   public static native void KepToUVW(double[] metricKep, double[] uBar, double[] vBar, double[] wBar);


   /**
   * Converts a set of classical elements to a set of equinoctial elements. 
   * @param metricClass The set of classical elements to be converted.
   * @param metricEqnx The resulting set of equinoctial elements.
   */
   public static native void ClassToEqnx(double[] metricClass, double[] metricEqnx);


   /**
   * Converts a set of equinoctial elements to a set of classical elements.
   * @param metricEqnx The set of equinoctial elements to be converted.
   * @param metricClass The resulting set of classical elements.
   */
   public static native void EqnxToClass(double[] metricEqnx, double[] metricClass);


   /**
   * Converts a set of equinoctial elements to a set of Keplerian elements. 
   * @param metricEqnx The set of equinoctial elements to be converted.
   * @param metricKep The resulting set of Keplerian elements.
   */
   public static native void EqnxToKep(double[] metricEqnx, double[] metricKep);


   /**
   * Converts a set of equinoctial elements to position and velocity vectors.
   * @param metricEqnx The set of equinoctial elements to be converted.
   * @param pos The resulting position vector.
   * @param vel The resulting velocity vector.
   */
   public static native void EqnxToPosVel(double[] metricEqnx, double[] pos, double[] vel);


   /**
   * Converts position and velocity vectors to a set of equinoctial elements.
   * @param pos The position vector to be converted.
   * @param vel The velocity vector to be converted.
   * @param metricEqnx The resulting set of equinoctial elements.
   */
   public static native void PosVelToEqnx(double[] pos, double[] vel, double[] metricEqnx);


   /**
   * Converts position and velocity vectors to a set of equinoctial elements with the given mu value. 
   * @param pos The position vector to be converted.
   * @param vel The velocity vector to be converted.
   * @param mu The value of mu.
   * @param metricEqnx The resulting set of equinoctial elements.
   */
   public static native void PosVelMuToEqnx(double[] pos, double[] vel, double mu, double[] metricEqnx);


   /**
   * Converts position and velocity vectors to a set of Keplerian elements.
   * @param pos The position vector to be converted.
   * @param vel The velocity vector to be converted.
   * @param metricKep The resulting set of Keplerian elements.
   */
   public static native void PosVelToKep(double[] pos, double[] vel, double[] metricKep);


   /**
   * Converts position and velocity vectors to a set of Keplerian elements with the given value of mu.
   * @param pos The position vector to be converted.
   * @param vel The velocity vector to be converted.
   * @param mu The value of mu.
   * @param metricKep The resulting set of Keplerian elements.
   */
   public static native void PosVelMuToKep(double[] pos, double[] vel, double mu, double[] metricKep);


   /**
   * Converts position and velocity vectors to U, V, W vectors. See the remarks section for details.
   * @param pos The position vector to be converted.
   * @param vel The velocity vector to be converted.
   * @param uVec The resulting U vector.
   * @param vVec The resulting V vector.
   * @param wVec The resulting W vector.
   */
   public static native void PosVelToUUVW(double[] pos, double[] vel, double[] uVec, double[] vVec, double[] wVec);


   /**
   * Converts position and velocity vectors to U, V, W vectors. See the remarks section for details.
   * @param pos The position vector.
   * @param vel The velocity vector.
   * @param uVec The resulting U vector.
   * @param vVec The resulting V vector.
   * @param wVec The resulting W vector.
   */
   public static native void PosVelToPTW(double[] pos, double[] vel, double[] uVec, double[] vVec, double[] wVec);


   /**
   * Solves Kepler's equation (M = E - e sin(E)) for the eccentric anomaly, E, by iteration.
   * @param metricKep The set of Keplerian elements for which to solve the equation.
   * @return The eccentric anomaly.
   */
   public static native double SolveKepEqtn(double[] metricKep);


   /**
   * Computes true anomaly from a set of Keplerian elements.
   * @param metricKep The set of Keplerian elements for which to compute true anomaly.
   * @return The true anomaly in degrees.
   */
   public static native double CompTrueAnomaly(double[] metricKep);


   /**
   * Converts mean motion N to semi-major axis A.
   * @param n Mean motion N (revs/day).
   * @return The semi-major axis A (km).
   */
   public static native double NToA(double n);


   /**
   * Converts semi-major axis A to mean motion N.
   * @param a Semi-major axis A (km).
   * @return The mean motion N (revs/day).
   */
   public static native double AToN(double a);


   /**
   * Converts Kozai mean motion to Brouwer mean motion.
   * @param eccen eccentricity
   * @param incli inclination (degrees)
   * @param nKozai Kozai mean motion (revs/day).
   * @return Brouwer mean motion (revs/day).
   */
   public static native double KozaiToBrouwer(double eccen, double incli, double nKozai);


   /**
   * Converts Brouwer mean motion to Kozai mean motion.
   * @param eccen eccentricity
   * @param incli inclination (degrees)
   * @param nBrouwer Brouwer mean motion (revs/day).
   * @return Kozai mean motion (revs/day).
   */
   public static native double BrouwerToKozai(double eccen, double incli, double nBrouwer);


   /**
   * Converts a set of osculating Keplerian elements to a set of mean Keplerian elements using method 9 algorithm.
   * @param metricOscKep The set of osculating Keplerian elements to be converted.
   * @param metricMeanKep The resulting set of mean Keplerian elements.
   */
   public static native void KepOscToMean(double[] metricOscKep, double[] metricMeanKep);


   /**
   * Converts an ECI position vector XYZ to geodetic latitude, longitude, and height.
   * @param thetaG ThetaG - Greenwich mean sidereal time (rad).
   * @param metricPos The ECI (TEME of Date) position vector (km) to be converted.
   * @param metricLLH The resulting geodetic north latitude (degree), east longitude(degree), and height (km).
   */
   public static native void XYZToLLH(double thetaG, double[] metricPos, double[] metricLLH);


   /**
   * Converts geodetic latitude, longitude, and height to an ECI position vector XYZ.
   * @param thetaG Theta - Greenwich mean sidereal time (rad).
   * @param metricLLH An array containing geodetic north latitude (degree), east longitude (degree), and height (km) to be converted.
   * @param metricXYZ The resulting ECI (TEME of Date) position vector (km).
   */
   public static native void LLHToXYZ(double thetaG, double[] metricLLH, double[] metricXYZ);


   /**
   * Converts EFG position and velocity vectors to ECI position and velocity vectors.
   * @param thetaG Theta - Greenwich mean sidereal time (rad).
   * @param posEFG The EFG position vector (km) to be converted.
   * @param velEFG The EFG velocity vector (km/s) to be converted.
   * @param posECI The resulting ECI (TEME of Date) position vector (km).
   * @param velECI The resulting ECI (TEME of Date) velocity vector (km/s).
   */
   public static native void EFGToECI(double thetaG, double[] posEFG, double[] velEFG, double[] posECI, double[] velECI);


   /**
   * Converts ECI position and velocity vectors to EFG position and velocity vectors.
   * @param thetaG Theta - Greenwich mean sidereal time (rad).
   * @param posECI The ECI (TEME of Date) position vector (km) to be converted.
   * @param velECI The ECI (TEME of Date) velocity vector (km/s) to be converted.
   * @param posEFG The resulting EFG position vector (km).
   * @param velEFG The resulting EFG velocity vector (km/s).
   */
   public static native void ECIToEFG(double thetaG, double[] posECI, double[] velECI, double[] posEFG, double[] velEFG);


   /**
   * Converts ECR position and velocity vectors to EFG position and velocity vectors.
   * @param polarX Polar motion X (arc-sec).
   * @param polarY Polar motion Y (arc-sec).
   * @param posECR The ECR position vector (km) to be converted.
   * @param velECR The ECR velocity vector (km/s) to be converted.
   * @param posEFG The resulting EFG position vector (km).
   * @param velEFG The resulting EFG velocity vector (km/s).
   */
   public static native void ECRToEFG(double polarX, double polarY, double[] posECR, double[] velECR, double[] posEFG, double[] velEFG);


   /**
   * Converts EFG position and velocity vectors to ECR position and velocity vectors.
   * @param polarX Polar motion X (arc-sec).
   * @param polarY Polar motion Y (arc-sec).
   * @param posEFG The EFG position vector (km) to be converted.
   * @param velEFG The EFG velocity vector (km/s) to be converted.
   * @param posECR The resulting ECR position vector (km).
   * @param velECR The resulting ECR velocity vector (km/s).
   */
   public static native void EFGToECR(double polarX, double polarY, double[] posEFG, double[] velEFG, double[] posECR, double[] velECR);


   /**
   * Converts an EFG position vector to geodetic latitude, longitude, and height.
   * @param posEFG The EFG position vector (km) to be converted.
   * @param metricLLH The resulting geodetic north latitude (degree), east longitude (degree), and height (km).
   */
   public static native void EFGPosToLLH(double[] posEFG, double[] metricLLH);


   /**
   * Converts geodetic latitude, longitude, and height to an EFG position vector.
   * @param metricLLH An Array containing the geodetic north latitude (degree), east longitude (degree), and height (km) to be converted.
   * @param posEFG The resulting EFG position vector (km).
   */
   public static native void LLHToEFGPos(double[] metricLLH, double[] posEFG);


   /**
   * Rotates position and velocity vectors from J2000 to coordinates of the specified date, expressed in ds50TAI.
   * @param spectr Specifies whether to run in SPECTR compatibility mode. A value of 1 means Yes.
   * @param nutationTerms Nutation terms (4-106, 4:less accurate, 106:most acurate).
   * @param ds50TAI The date to rotate to coordinates of, expressed in days since 1950, TAI.
   * @param posJ2K The position vector from J2000.
   * @param velJ2K The velocity vector from J2000.
   * @param posDate The resulting position vector in coordinates of date, ds50TAI.
   * @param velDate The resulting velocity vector in coordinates of date, ds50TAI.
   */
   public static native void RotJ2KToDate(int spectr, int nutationTerms, double ds50TAI, double[] posJ2K, double[] velJ2K, double[] posDate, double[] velDate);


   /**
   * Rotates position and velocity vectors from coordinates of date to J2000.
   * @param spectr Specifies whether to run in SPECTR compatibility mode. A value of 1 means Yes.
   * @param nutationTerms Nutation terms (4-106, 4:less accurate, 106:most acurate).
   * @param ds50TAI Time in days since 1950, TAI for which the coordinates of position and velocity vectors are currently expressed.
   * @param posDate The position vector from coordinates of Date.
   * @param velDate The velocity vector from coordinates of Date.
   * @param posJ2K The resulting position vector in coordinates of J2000.
   * @param velJ2K The resulting velocity vector in coordinates of J2000.
   */
   public static native void RotDateToJ2K(int spectr, int nutationTerms, double ds50TAI, double[] posDate, double[] velDate, double[] posJ2K, double[] velJ2K);


   /**
   * Computes the Sun and Moon position at the specified time.
   * @param ds50ET The number of days since 1950, ET for which to compute the sun and moon position.
   * @param uvecSun The resulting sun position unit vector.
   * @param sunVecMag The resulting magnitude of the sun position vector (km).
   * @param uvecMoon The resulting moon position unit vector.
   * @param moonVecMag The resulting magnitude of the moon position vector (km).
   */
   public static native void CompSunMoonPos(double ds50ET, double[] uvecSun, DoubleByReference sunVecMag, double[] uvecMoon, DoubleByReference moonVecMag);


   /**
   * Computes the Sun position at the specified time.
   * @param ds50ET The number of days since 1950, ET for which to compute the sun position.
   * @param uvecSun The resulting sun position unit vector.
   * @param sunVecMag The resulting magnitude of the sun position vector (km).
   */
   public static native void CompSunPos(double ds50ET, double[] uvecSun, DoubleByReference sunVecMag);


   /**
   * Computes the Moon position at the specified time.
   * @param ds50ET The number of days since 1950, ET for which to compute the moon position.
   * @param uvecMoon The resulting moon position unit vector.
   * @param moonVecMag The resulting magnitude of the moon position vector (km).
   */
   public static native void CompMoonPos(double ds50ET, double[] uvecMoon, DoubleByReference moonVecMag);


   /**
   * This function is intended for future use.  No information is currently available.
   * @param xf_Conv Index of the conversion function
   * @param frArr The input array
   * @param toArr The resulting array
   */
   public static native void AstroConvFrTo(int xf_Conv, double[] frArr, double[] toArr);


   /**
   * Converts right ascension and declination to vector triad LAD in topocentric equatorial coordinate system.
   * @param RA Right ascension (deg).
   * @param dec Declination (deg).
   * @param L The resulting unit vector from the station to the satellite (referred to the equatorial coordinate system axis).
   * @param A_Tilde The resulting unit vector perpendicular to the hour circle passing through the satellite, in the direction of increasing RA.
   * @param D_Tilde The resulting unit vector perpendicular to L and is directed toward the north, in the plane of the hour circle.
   */
   public static native void RADecToLAD(double RA, double dec, double[] L, double[] A_Tilde, double[] D_Tilde);


   /**
   * Converts azimuth and elevation to vector triad LAD in topocentric horizontal coordinate system.
   * @param az Input azimuth (deg).
   * @param el Input elevation angle (deg).
   * @param Lh The resulting unit vector from the station to the satellite (referred to the horizon coordinate system axis).
   * @param Ah The resulting unit vector perpendicular to the hour circle passing through the satellite, in the direction of increasing Az.
   * @param Dh The resulting unit vector perpendicular to L and is directed toward the zenith, in the plane of the hour circle.
   */
   public static native void AzElToLAD(double az, double el, double[] Lh, double[] Ah, double[] Dh);


   /**
   * Converts satellite ECI position/velocity vectors and sensor location to topocentric components.
   * @param theta Theta - local sidereal time(rad).
   * @param lat Station's astronomical latitude (deg). (+N) (-S)
   * @param senPos Sensor position in ECI (km).
   * @param satPos Satellite position in ECI (km).
   * @param satVel Satellite velocity in ECI (km/s).
   * @param xa_topo An array that stores the resulting topocentric components.
   */
   public static native void ECIToTopoComps(double theta, double lat, double[] senPos, double[] satPos, double[] satVel, double[] xa_topo);


   /**
   * Converts right ascension and declination in the topocentric reference frame to Azimuth/Elevation in the local horizon reference frame.
   * @param thetaG Theta - Greenwich mean sidereal time (rad).
   * @param lat Station's astronomical latitude (deg). (+N) (-S)
   * @param lon Station's astronomical longitude (deg). (+E) (-W)
   * @param RA Right ascension (deg)
   * @param dec Declination (deg)
   * @param az Azimuth (deg)
   * @param el Elevation (deg)
   */
   public static native void RaDecToAzEl(double thetaG, double lat, double lon, double RA, double dec, DoubleByReference az, DoubleByReference el);


   /**
   * Converts full state RAE (range, az, el, and their rates) to full state ECI (position and velocity)
   * @param theta Theta - local sidereal time(rad).
   * @param astroLat Astronomical latitude (ded).
   * @param xa_rae An array contains input data.
   * @param senPos Sensor position in ECI (km).
   * @param satPos Satellite position in ECI (km).
   * @param satVel Satellite velocity in ECI (km/s).
   */
   public static native void RAEToECI(double theta, double astroLat, double[] xa_rae, double[] senPos, double[] satPos, double[] satVel);


   /**
   * Computes initial values for the SGP drag term NDOT and the SGP4 drag term BSTAR based upon eccentricity and semi-major axis.
   * @param semiMajorAxis Semi-major axis (km).
   * @param eccen Eccentricity (unitless).
   * @param ndot Ndot (revs/day^2).
   * @param bstar Bstar (1/earth radii).
   */
   public static native void GetInitialDrag(double semiMajorAxis, double eccen, DoubleByReference ndot, DoubleByReference bstar);


   /**
   * Converts covariance matrix PTW to UVW.
   * @param pos The input position vector (km).
   * @param vel The input velocity vector (km/s).
   * @param ptwCovMtx The PTW covariance matrix to be converted.
   * @param uvwCovMtx The resulting UVW covariance matrix.
   */
   public static native void CovMtxPTWToUVW(double[] pos, double[] vel, double[] ptwCovMtx, double[] uvwCovMtx);


   /**
   * Converts covariance matrix UVW to PTW.
   * @param pos The input position vector (km).
   * @param vel The input velocity vector (km/s).
   * @param uvwCovMtx The UVW covariance matrix to be converted.
   * @param ptwCovMtx The resulting PTW covariance matrix.
   */
   public static native void CovMtxUVWToPTW(double[] pos, double[] vel, double[] uvwCovMtx, double[] ptwCovMtx);


   /**
   * Computes Earth/Sensor/Earth Limb and Earth/Sensor/Satellite angles.
   * @param earthLimb Earth limb distance (km).
   * @param satECI Satellite position in ECI (km).
   * @param senECI Sensor position in ECI (km).
   * @param earthSenLimb The resulting earth/sensor/limb angle (deg).
   * @param earthSenSat The resulting earth/sensor/sat angle (deg).
   * @param satEarthSen The resulting sat/earth/sensor angle (deg).
   */
   public static native void EarthObstructionAngles(double earthLimb, double[] satECI, double[] senECI, DoubleByReference earthSenLimb, DoubleByReference earthSenSat, DoubleByReference satEarthSen);
   
   // Index of Keplerian elements
   public static final int  
      XA_KEP_A     =   0,       // semi-major axis (km)
      XA_KEP_E     =   1,       // eccentricity (unitless)
      XA_KEP_INCLI =   2,       // inclination (deg)
      XA_KEP_MA    =   3,       // mean anomaly (deg)
      XA_KEP_NODE  =   4,       // right ascension of the asending node (deg)
      XA_KEP_OMEGA =   5;       // argument of perigee (deg)
      
   // Index of classical elements
   public static final int  
      XA_CLS_N     =   0,       // N mean motion (revs/day)
      XA_CLS_E     =   1,       // eccentricity (unitless)
      XA_CLS_INCLI =   2,       // inclination (deg)
      XA_CLS_MA    =   3,       // mean anomaly (deg)
      XA_CLS_NODE  =   4,       // right ascension of the asending node (deg)
      XA_CLS_OMEGA =   5;       // argument of perigee (deg)
   
   // Index of equinoctial elements
   public static final int  
      XA_EQNX_AF   =   0,       // Af (unitless) 
      XA_EQNX_AG   =   1,       // Ag (unitless)
      XA_EQNX_CHI  =   2,       // Chi (unitless)
      XA_EQNX_PSI  =   3,       // Psi (unitless)
      XA_EQNX_L    =   4,       // L mean longitude (deg)
      XA_EQNX_N    =   5;       // N mean motion (revs/day)
      
   // Indexes of AstroConvFrTo
   public static final int  
      XF_CONV_SGP42SGP = 101;        // SGP4 (A, E, Incli, BStar) to SGP (Ndot, N2Dot)
   
   
   // Indexes for topocentric components
   public static final int  
      XA_TOPO_RA    = 0,         // Right ascension (deg)
      XA_TOPO_DEC   = 1,         // Declination (deg)
      XA_TOPO_AZ    = 2,         // Azimuth (deg)
      XA_TOPO_EL    = 3,         // Elevation (deg)
      XA_TOPO_RANGE = 4,         // Range (km)
      XA_TOPO_RADOT = 5,         // Right ascension dot (deg/s)
      XA_TOPO_DECDOT= 6,         // Declincation dot (deg/s)
      XA_TOPO_AZDOT = 7,         // Azimuth dot (deg/s)
      XA_TOPO_ELDOT = 8,         // Elevation dot (deg/s)
      XA_TOPO_RANGEDOT = 9;      // Range dot (km/s)   
      
      
   // Indexes for RAE components
   public static final int  
      XA_RAE_RANGE   = 0,        // Range (km)
      XA_RAE_AZ      = 1,        // Azimuth (deg)
      XA_RAE_EL      = 2,        // Elevation (deg)
      XA_RAE_RANGEDOT= 3,        // Range dot (km/s)   
      XA_RAE_AZDOT   = 4,        // Azimuth dot (deg/s)
      XA_RAE_ELDOT   = 5;        // Elevation dot (deg/s)
      
// ========================= End of auto generated code ==========================
}
