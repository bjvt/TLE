package afspc.astrostds.services;
import java.io.*;
import java.io.Reader;
import java.util.Date;
import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Platform;
import com.sun.jna.PointerType;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.DoubleByReference;
import afspc.astrostds.wrappers.JnaEnvConst;
import afspc.astrostds.utilities.Utility;



public class SrvEnvConst
{
}
