Java Driver examples contains these folder:
	+ source: This folder contains java source files that are used to create utility and jna classes. The batch file "CreateJavaClasses.bat" compiles all the java source files and generates/stores java classes in "classes" folder.

	+ classes: This folder contains the java classes that were created from java files in the "source" folder. The classes in this folder are utility and jna classes that will be needed to any java applications that call the Astro Standards dlls.

	+ Java_Sgp4Prop: Sample java code that shows how a java program can call the Astro Standards dlls (via jna classes) to propagate a satellite using the Sgp4 propagator. The batch file "runJavaSgp4Prop.bat" compiles and runs the Java_Sgp4Prop program with a test case "rel14.inp"
   
   + Java_SpProp: Sample java code that shows how a java program can call the Astro Standards dlls (via jna classes) to propagate a satellite using the SP propagator. The batch file "runJavaSpProp.bat" compiles and runs the Java_SpProp program with a test case "Vcm1.inp".

Note: Make sure the JVM and the Astro Standards dlls are of the same platform/architecture (both have the same 32-bit or 64-bit architecture). If not, the user will receive an exception like this:

C:\AstroStds\Temp\DriverExamples\Java\Java_SpProp>java  -cp .\;..\classes;..\cla
sses\jna.jar Java_SpProp vcm1.inp vcm1.out
Exception in thread "main" java.lang.UnsatisfiedLinkError: Unable to load librar
y 'DllMain': The specified module could not be found.

        at com.sun.jna.NativeLibrary.loadLibrary(NativeLibrary.java:169)
        at com.sun.jna.NativeLibrary.getInstance(NativeLibrary.java:242)
        at com.sun.jna.NativeLibrary.getInstance(NativeLibrary.java:205)
        at com.sun.jna.Native.register(Native.java:1033)
        at jnaDllMain.<clinit>(jnaDllMain.java:20)
        at Java_SpProp.<clinit>(Java_SpProp.java:52)
Could not find the main class: Java_SpProp.  Program will exit.


The users can issue command "java -version" to find out what version of the JVM they are using.