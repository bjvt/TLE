#!/bin/bash

clear 
echo "------------ Begin Java Test ---------------"

CWD=$(pwd)
CLSPATH="$CWD:/root/Astrostandards/SGP4/Driver_Examples/Java/classes:/root/Astrostandards/SGP4/Driver_Examples/Java/classes/jna.jar"
LIBPATH="../../LibLinux"
LIBPATHFULL="/root/Astrostandards/SGP4/LibLinux"	# /Lib/*.dll moved/renamed to /LibLinux/lib*.so
SOURCE="Java_Sgp4Prop_Simple"

export LD_LIBRARY_PATH=./:$LIBPATHFULL:$LD_LIBRARY_PATH

echo $CLSPATH
echo $SOURCE
echo $LD_LIBRARY_PATH

# /usr/lib/jvm/java-1.8.0-openjdk.x86_64/bin/javac
# /usr/lib/jvm/java-openjdk/bin/javac

echo "compile"
/usr/lib/jvm/java-openjdk/bin/javac -cp $CLSPATH $SOURCE.java

echo "run"
/usr/lib/jvm/java-openjdk/bin/java -cp $CLSPATH $SOURCE

/usr/lib/jvm/java-openjdk/bin/java -version

echo "------------ End Java Test ---------------"


