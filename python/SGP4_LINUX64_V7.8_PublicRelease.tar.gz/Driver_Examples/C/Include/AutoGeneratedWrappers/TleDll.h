// This wrapper file was generated automatically by the A3\GenDllWrappers program.

#ifndef TLEDLL_H
#define TLEDLL_H

#include "../DllUtils.h"

// Provide the path to the dll
#define TleDll "Tle.dll"


// Initializes Tle DLL for use in the program.
// apPtr: The handle that was returned from DllMainInit. See the documentation for DllMain.dll for details.
// returns 0 if Tle.dll is initialized successfully, non-0 if there is an error.
typedef int (STDCALL *fnPtrTleInit)(__int64 apPtr);


// Returns the information about the Tle DLL.
// infoStr: A string to hold the information about the Tle DLL.
typedef void (STDCALL *fnPtrTleGetInfo)(char infoStr[128]);


// Loads TLEs (satellites) contained in a text file into the TLE DLL's binary tree.
// tleFile: The name of the file containing two line element sets to be loaded.
// returns 0 if the two line element sets in the file are successfully loaded, non-0 if there is an error.
typedef int (STDCALL *fnPtrTleLoadFile)(char tleFile[512]);


// Saves currently loaded TLEs to a file. 
// tleFile: The name of the file in which to save the TLE's.
// saveMode: Specifies whether to create a new file or append to an existing file. (0 = create new file, 1= append to existing file)
// saveForm: Specifies the format in which to save the file. (0 = two-line element set format, 2 = XML format (future implementation))
// returns 0 if the data is successfully saved to the file, non-0 if there is an error.
typedef int (STDCALL *fnPtrTleSaveFile)(char tleFile[512], int saveMode, int saveForm);


// Removes a TLE represented by the satKey from memory. 
// satKey: The unique key of the satellite to be removed.
// returns 0 if the TLE is removed successfully, non-0 if there is an error.
typedef int (STDCALL *fnPtrTleRemoveSat)(__int64 satKey);


// Removes all the TLEs from memory.
// returns 0 if all TLE's are removed successfully from memory, non-0 if there is an error.
typedef int (STDCALL *fnPtrTleRemoveAllSats)();


// Returns the number of TLEs currently loaded. 
// returns The number of TLEs currently loaded.
typedef int (STDCALL *fnPtrTleGetCount)();


// Retrieves all of the currently loaded satKeys. These satKeys can be used to access the internal data for the TLE's.
// order: Specifies the order in which the satKeys should be returned. 0 = sort in ascending order of satKeys, 1 = sort in descending order of satKeys, 2 = sort in the order in which the satKeys were loaded in memory, 9 = Quickest: sort in the order in which the satKeys were stored in the tree
// satKeys: The array in which to store the satKeys.
typedef void (STDCALL *fnPtrTleGetLoaded)(int order, __int64* satKeys);


// Adds a TLE (satellite), using its directly specified first and second lines. 
// line1: The first line of a two line element set.
// line2: The second line of a two line element set.
// returns The satKey of the newly added TLE on success, a negative value on error.
typedef __int64 (STDCALL *fnPtrTleAddSatFrLines)(char line1[512], char line2[512]);


// This function is similar to TleAddSatFrLines but designed to be used in Matlab.
// line1: The first line of a two line element set.
// line2: The second line of a two line element set.
// satKey: The satKey of the newly added TLE on success, a negative value on error.
typedef void (STDCALL *fnPtrTleAddSatFrLinesML)(char line1[512], char line2[512], __int64* satKey);


// Adds a GP TLE using its individually provided field values. 
// satNum: Satellite number
// secClass: Security classification
// satName: Satellite international designator
// epochYr: Element epoch time - year, [YY]YY
// epochDays: Element epoch time - day of year, DDD.DDDDDDDD
// bstar: B* drag term (1/er)
// ephType: Satellite ephemeris type (0: SGP, 2: SGP4)
// elsetNum: Element set number
// incli: Orbit inclination (degrees)
// node: Right ascension of ascending node (degrees)
// eccen: Eccentricity
// omega: Argument of perigee (degrees)
// mnAnomaly: Mean anomaly (degrees)
// mnMotion: Mean motion (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
// revNum: Revolution number at epoch
// returns The satKey of the newly added TLE on success, a negative value on error.
typedef __int64 (STDCALL *fnPtrTleAddSatFrFieldsGP)(int satNum, char secClass, char satName[8], int epochYr, double epochDays, double bstar, int ephType, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum);


// This function is similar to TleAddSatFrFieldsGP but includes nDotO2 and n2DotO6. 
// satNum: Satellite number
// secClass: Security classification
// satName: Satellite international designator
// epochYr: Element epoch time - year, [YY]YY
// epochDays: Element epoch time - day of year, DDD.DDDDDDDD
// bstar: B* drag term (1/er)
// ephType: Satellite ephemeris type (0: SGP, 2: SGP4)
// elsetNum: Element set number
// incli: Orbit inclination (degrees)
// node: Right ascension of ascending node (degrees)
// eccen: Eccentricity
// omega: Argument of perigee (degrees)
// mnAnomaly: Mean anomaly (degrees)
// mnMotion: Mean motion (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
// revNum: Revolution number at epoch
// nDotO2: Mean motion derivative (rev/day /2)
// n2DotO6: Mean motion second derivative (rev/day**2 /6)
// returns The satKey of the newly added TLE on success, a negative value on error.
typedef __int64 (STDCALL *fnPtrTleAddSatFrFieldsGP2)(int satNum, char secClass, char satName[8], int epochYr, double epochDays, double bstar, int ephType, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum, double nDotO2, double n2DotO6);


// This function is similar to TleAddSatFrFieldsGP2 but designed to be used in Matlab. 
// satNum: Satellite number
// secClass: Security classification
// satName: Satellite international designator
// epochYr: Element epoch time - year, [YY]YY
// epochDays: Element epoch time - day of year, DDD.DDDDDDDD
// bstar: B* drag term (1/er)
// ephType: Satellite ephemeris type (0: SGP, 2: SGP4)
// elsetNum: Element set number
// incli: Orbit inclination (degrees)
// node: Right ascension of ascending node (degrees)
// eccen: Eccentricity
// omega: Argument of perigee (degrees)
// mnAnomaly: Mean anomaly (degrees)
// mnMotion: Mean motion (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
// revNum: Revolution number at epoch
// nDotO2: Mean motion derivative (rev/day /2)
// n2DotO6: Mean motion second derivative (rev/day**2 /6)
// satKey: The satKey of the newly added TLE on success, a negative value on error.
typedef void (STDCALL *fnPtrTleAddSatFrFieldsGP2ML)(int satNum, char secClass, char satName[8], int epochYr, double epochDays, double bstar, int ephType, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum, double nDotO2, double n2DotO6, __int64* satKey);


// Updates a GP satellite's data in memory by providing its individual field values. 
// satKey: The satellite's unique key
// secClass: Security classification
// satName: Satellite international designator
// bstar: B* drag term (1/er)
// elsetNum: Element set number
// incli: Orbit inclination (degrees)
// node: Right ascension of ascending node (degrees)
// eccen: Eccentricity
// omega: Argument of perigee (degrees)
// mnAnomaly: Mean anomaly (degrees)
// mnMotion: Mean motion  (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
// revNum: Revolution number at epoch
// returns 0 if the TLE is successfully updated, non-0 if there is an error.
typedef int (STDCALL *fnPtrTleUpdateSatFrFieldsGP)(__int64 satKey, char secClass, char satName[8], double bstar, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum);


// This function is similar to TleUpdateSatFrFieldsGP but includes nDotO2 and n2DotO6.
// satKey: The satellite's unique key
// secClass: Security classification
// satName: Satellite international designator
// bstar: B* drag term (1/er)
// elsetNum: Element set number
// incli: Orbit inclination (degrees)
// node: Right ascension of ascending node (degrees)
// eccen: Eccentricity
// omega: Argument of perigee (degrees)
// mnAnomaly: Mean anomaly (degrees)
// mnMotion: Mean motion  (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
// revNum: Revolution number at epoch
// nDotO2: Mean motion derivative (rev/day /2)
// n2DotO6: Mean motion second derivative (rev/day**2 /6)
// returns 0 if the TLE is successfully updated, non-0 if there is an error.
typedef int (STDCALL *fnPtrTleUpdateSatFrFieldsGP2)(__int64 satKey, char secClass, char satName[8], double bstar, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum, double nDotO2, double n2DotO6);


// Adds an SP satellite using the individually provided field values.
// satNum: Satellite number
// secClass: Security classification
// satName: Satellite international designator
// epochYr: Element epoch time - year, [YY]YY
// epochDays: Element epoch time - day of year, DDD.DDDDDDDD
// bTerm: Ballistic coefficient (m^2/kg)
// ogParm: Outgassing parameter/Thrust Acceleration (km/s^2)
// agom: Agom (m^2/kg)
// elsetNum: Element set number
// incli: Orbit inclination (degrees)
// node: Right ascension of ascending node (degrees)
// eccen: Eccentricity
// omega: Argument of perigee (degrees)
// mnAnomaly: Mean anomaly (degrees)
// mnMotion: Mean motion (rev/day)
// revNum: Revolution number at epoch
// returns The satKey of the newly added TLE on success, a negative value on error.
typedef __int64 (STDCALL *fnPtrTleAddSatFrFieldsSP)(int satNum, char secClass, char satName[8], int epochYr, double epochDays, double bTerm, double ogParm, double agom, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum);


// This function is similar to TleAddSatFrFieldsSP but designed to be used in Matlab.
// satNum: Satellite number
// secClass: Security classification
// satName: Satellite international designator
// epochYr: Element epoch time - year, [YY]YY
// epochDays: Element epoch time - day of year, DDD.DDDDDDDD
// bTerm: Ballistic coefficient (m^2/kg)
// ogParm: Outgassing parameter/Thrust Acceleration (km/s^2)
// agom: Agom (m^2/kg)
// elsetNum: Element set number
// incli: Orbit inclination (degrees)
// node: Right ascension of ascending node (degrees)
// eccen: Eccentricity
// omega: Argument of perigee (degrees)
// mnAnomaly: Mean anomaly (degrees)
// mnMotion: Mean motion (rev/day)
// revNum: Revolution number at epoch
// satKey: The satKey of the newly added TLE on success, a negative value on error.
typedef void (STDCALL *fnPtrTleAddSatFrFieldsSPML)(int satNum, char secClass, char satName[8], int epochYr, double epochDays, double bTerm, double ogParm, double agom, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum, __int64* satKey);


// Updates an SP satellite's data in memory using its individually provided field values.
// satKey: The satellite's unique key
// secClass: Security classification
// satName: Satellite international designator
// bterm: Ballistic coefficient (m^2/kg)
// ogParm: Outgassing parameter/Thrust Acceleration (km/s^2)
// agom: Agom (m^2/kg)
// elsetNum: Element set number
// incli: Orbit inclination (degrees)
// node: Right ascension of ascending node (degrees)
// eccen: Eccentricity
// omega: Argument of perigee (degrees)
// mnAnomaly: Mean anomaly (degrees)
// mnMotion: Mean motion (rev/day)
// revNum: Revolution number at epoch
// returns 0 if the TLE is successfully updated, non-0 if there is an error.
typedef int (STDCALL *fnPtrTleUpdateSatFrFieldsSP)(__int64 satKey, char secClass, char satName[8], double bterm, double ogParm, double agom, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum);


// Updates the value of a field of a TLE. This function can be used for both GP and SP satellites.
// satKey: The satellite's unique key.
// xf_Tle: Predefined number specifying which field to set. See remarks.
// valueStr: The new value of the specified field, expressed as a string.
// returns 0 if the TLE is successfully updated, non-0 if there is an error
typedef int (STDCALL *fnPtrTleSetField)(__int64 satKey, int xf_Tle, char valueStr[512]);


// Retrieves the value of a specific field of a TLE. 
// satKey: The satellite's unique key.
// xf_Tle: Predefined number specifying which field to retrieve. See remarks.
// valueStr: A string to contain the value of the requested field.
// returns 0 if the TLE data is successfully retrieved, non-0 if there is an error.
typedef int (STDCALL *fnPtrTleGetField)(__int64 satKey, int xf_Tle, char valueStr[512]);


// Retrieves all of the data for a GP satellite in a single function call. 
// satKey: The satellite's unique key
// satNum: Satellite number
// secClass: Security classification
// satName: Satellite international designator
// epochYr: Element epoch time - year, [YY]YY
// epochDays: Element epoch time - day of year, DDD.DDDDDDDD
// bstar: B* drag term (1/er)
// ephType: Satellite ephemeris type (0: SGP, 2: SGP4, 6: SP)
// elsetNum: Element set number
// incli: Orbit inclination (degrees)
// node: Right ascension of ascending node (degrees)
// eccen: Eccentricity
// omega: Argument of perigee (degrees)
// mnAnomaly: Mean anomaly (deg)
// mnMotion: Mean motion (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
// revNum: Revolution number at epoch
// returns 0 if all values are retrieved successfully, non-0 if there is an error.
typedef int (STDCALL *fnPtrTleGetAllFieldsGP)(__int64 satKey, int* satNum, char* secClass, char satName[8], int* epochYr, double* epochDays, double* bstar, int* ephType, int* elsetNum, double* incli, double* node, double* eccen, double* omega, double* mnAnomaly, double* mnMotion, int* revNum);


// Retrieves all of the data (including nDotO2 and n2DotO6) for a GP satellite in a single function call. 
// satKey: The satellite's unique key
// satNum: Satellite number
// secClass: Security classification
// satName: Satellite international designator
// epochYr: Element epoch time - year, [YY]YY
// epochDays: Element epoch time - day of year, DDD.DDDDDDDD
// bstar: B* drag term (1/er)
// ephType: Satellite ephemeris type (0: SGP, 2: SGP4, 6: SP)
// elsetNum: Element set number
// incli: Orbit inclination (degrees)
// node: Right ascension of ascending node (degrees)
// eccen: Eccentricity
// omega: Argument of perigee (degrees)
// mnAnomaly: Mean anomaly (degrees)
// mnMotion: Mean motion (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
// revNum: Revolution number at epoch
// nDotO2: Mean motion derivative (rev/day /2)
// n2DotO6: Mean motion second derivative (rev/day**2 /6)
// returns 0 if all values are retrieved successfully, non-0 if there is an error.
typedef int (STDCALL *fnPtrTleGetAllFieldsGP2)(__int64 satKey, int* satNum, char* secClass, char satName[8], int* epochYr, double* epochDays, double* bstar, int* ephType, int* elsetNum, double* incli, double* node, double* eccen, double* omega, double* mnAnomaly, double* mnMotion, int* revNum, double* nDotO2, double* n2DotO6);


// Retrieves all of the data for an SP satellite in a single function call.
// satKey: The satellite's unique key
// satNum: Satellite number
// secClass: Security classification
// satName: Satellite international designator
// epochYr: Element epoch time - year, [YY]YY
// epochDays: Element epoch time - day of year, DDD.DDDDDDDD
// bTerm: Ballistic coefficient (m^2/kg)
// ogParm: Outgassing parameter/Thrust Acceleration (km/s^2)
// agom: Agom (m^2/kg)
// elsetNum: Element set number
// incli: Orbit inclination (degrees)
// node: Right ascension of ascending node (degrees)
// eccen: Eccentricity
// omega: Argument of perigee (degrees)
// mnAnomaly: Mean anomaly (degrees)
// mnMotion: Mean motion (rev/day)
// revNum: Revolution number at epoch
// returns 0 if all values are retrieved successfully, non-0 if there is an error.
typedef int (STDCALL *fnPtrTleGetAllFieldsSP)(__int64 satKey, int* satNum, char* secClass, char satName[8], int* epochYr, double* epochDays, double* bTerm, double* ogParm, double* agom, int* elsetNum, double* incli, double* node, double* eccen, double* omega, double* mnAnomaly, double* mnMotion, int* revNum);


// Parses GP data from the input first and second lines of a two line element set.
// line1: The first line of the two line element set.
// line2: The second line of the two line element set.
// satNum: Satellite number
// secClass: Security classification
// satName: Satellite international designator
// epochYr: Element epoch time - year, [YY]YY
// epochDays: Element epoch time - day of year, DDD.DDDDDDDD
// nDotO2: n-dot/2 (for SGP, ephType = 0)
// n2DotO6: n-double-dot/6 (for SGP, ephType = 0)
// bstar: B* drag term (1/er)
// ephType: Satellite ephemeris type (0: SGP, 2: SGP4, 6: SP)
// elsetNum: Element set number
// incli: Orbit inclination (degrees)
// node: Right ascension of ascending node (degrees).
// eccen: Eccentricity
// omega: Argument of perigee (degrees)
// mnAnomaly: Mean anomaly (degrees)
// mnMotion: Mean motion (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
// revNum: Revolution number at epoch
// returns 0 if the TLE is parsed successfully, non-0 if there is an error.
typedef int (STDCALL *fnPtrTleParseGP)(char line1[512], char line2[512], int* satNum, char* secClass, char satName[8], int* epochYr, double* epochDays, double* nDotO2, double* n2DotO6, double* bstar, int* ephType, int* elsetNum, double* incli, double* node, double* eccen, double* omega, double* mnAnomaly, double* mnMotion, int* revNum);


// Parses SP data from the input first and second lines of a two line element set.
// line1: The first line of the two line element set.
// line2: The second line of the two line element set.
// satNum: Satellite number
// secClass: Security classification
// satName: Satellite international designator
// epochYr: Element epoch time - year, [YY]YY
// epochDays: Element epoch time - day of year, DDD.DDDDDDDD
// bTerm: Ballistic coefficient (m^2/kg).
// ogParm: Outgassing parameter/Thrust Acceleration (km/s^2)
// agom: Agom (m^2/kg)
// elsetNum: Element set number
// incli: Orbit inclination (degrees)
// node: Right ascension of ascending node (degrees)
// eccen: Eccentricity
// omega: Argument of perigee (degrees)
// mnAnomaly: Mean anomaly (degrees)
// mnMotion: Mean motion (rev/day)
// revNum: Revolution number at epoch
// returns 0 if the TLE is parsed successfully, non-0 if there is an error.
typedef int (STDCALL *fnPtrTleParseSP)(char line1[512], char line2[512], int* satNum, char* secClass, char satName[8], int* epochYr, double* epochDays, double* bTerm, double* ogParm, double* agom, int* elsetNum, double* incli, double* node, double* eccen, double* omega, double* mnAnomaly, double* mnMotion, int* revNum);


// Returns the first and second lines representation of a TLE of a satellite. 
// satKey: The satellite's unique key.
// line1: A string to hold the first line of the TLE.
// line2: A string to hold the second line of the TLE.
// returns 0 if successful, non-0 on error.
typedef int (STDCALL *fnPtrTleGetLines)(__int64 satKey, char line1[512], char line2[512]);


// Constructs a TLE from individually provided GP data fields.
// satNum: Satellite number
// secClass: Security classification
// satName: Satellite international designator
// epochYr: Element epoch time - year, [YY]YY
// epochDays: Element epoch time - day of year, DDD.DDDDDDDD
// nDotO2: N Dot/2 (rev/day /2)
// n2DotO6: N Double Dot/6 (rev/day**2 /6)
// bstar: B* drag term (1/er)
// ephType: Satellite ephemeris type (0: SGP, 2: SGP4)
// elsetNum: Element set number
// incli: Orbit inclination (degrees)
// node: Right ascension of ascending node (degrees)
// eccen: Eccentricity
// omega: Argument of perigee (degrees)
// mnAnomaly: Mean anomaly (degrees)
// mnMotion: Mean motion (rev/day) (ephType = 0: Kozai mean motion, ephType = 2: Brouwer mean motion)
// revNum: Revolution number at epoch
// line1: Returned first line of a TLE.
// line2: Returned second line of a TLE.
typedef void (STDCALL *fnPtrTleGPFieldsToLines)(int satNum, char secClass, char satName[8], int epochYr, double epochDays, double nDotO2, double n2DotO6, double bstar, int ephType, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum, char line1[512], char line2[512]);


// Constructs a TLE from individually provided SP data fields.
// satNum: Satellite number
// secClass: Security classification
// satName: Satellite international designator
// epochYr: Element epoch time - year, [YY]YY
// epochDays: Element epoch time - day of year, DDD.DDDDDDDD
// bTerm: Ballistic coefficient (m^2/kg)
// ogParm: Outgassing parameter/Thrust Acceleration (km/s^2)
// agom: Agom (m^2/kg)
// elsetNum: Element set number
// incli: Orbit inclination (degrees)
// node: Right ascension of ascending node (degrees)
// eccen: Eccentricity
// omega: Argument of perigee (degrees)
// mnAnomaly: Mean anomaly (degrees)
// mnMotion: Mean motion (rev/day)
// revNum: Revolution number at epoch
// line1: Returned first line of a TLE.
// line2: Returned second line of a TLE.
typedef void (STDCALL *fnPtrTleSPFieldsToLines)(int satNum, char secClass, char satName[8], int epochYr, double epochDays, double bTerm, double ogParm, double agom, int elsetNum, double incli, double node, double eccen, double omega, double mnAnomaly, double mnMotion, int revNum, char line1[512], char line2[512]);


// Returns the first satKey from the currently loaded set of TLEs that contains the specified satellite number.
// satNum: Satellite number
// returns The satellite's unique key
typedef __int64 (STDCALL *fnPtrTleGetSatKey)(int satNum);


// This function is similar to TleGetSatKey but designed to be used in Matlab. 
// satNum: Satellite number
// satKey: The satKey of the satellite if a satellite with the requested number is found in the set of loaded satellites, a negative value if there is an error.
typedef void (STDCALL *fnPtrTleGetSatKeyML)(int satNum, __int64* satKey);


// Computes a satKey from the input data.
// satNum: Satellite number
// epochYr: Element epoch time - year, [YY]YY
// epochDays: Element epoch time - day of year, DDD.DDDDDDDD
// ephType: Ephemeris type
// returns The resulting satellite key if the computation is successful; a negative value if there is an error.
typedef __int64 (STDCALL *fnPtrTleFieldsToSatKey)(int satNum, int epochYr, double epochDays, int ephType);


// This function is similar to TleFieldsToSatKey but designed to be used in Matlab. 
// satNum: Satellite number
// epochYr: Element epoch time - year, [YY]YY
// epochDays: Element epoch time - day of year, DDD.DDDDDDDD
// ephType: Ephemeris type
// satKey: The satKey if the computation is successful, a negative value if there is an error.
typedef void (STDCALL *fnPtrTleFieldsToSatKeyML)(int satNum, int epochYr, double epochDays, int ephType, __int64* satKey);
  
// Indexes of TLE data fields
static const int  
   XF_TLE_SATNUM     =  1,    // Satellite number
   XF_TLE_CLASS      =  2,    // Security classification U: unclass, C: confidential, S: Secret
   XF_TLE_SATNAME    =  3,    // Satellite name A8
   XF_TLE_EPOCH      =  4,    // Satellite's epoch time "YYYYJJJ.jjjjjjjj"
   XF_TLE_BSTAR      =  5,    // GP B* drag term (1/er)  
   XF_TLE_SP_AGOM    =  5,    // SP Radiation Pressure Coefficient
   XF_TLE_EPHTYPE    =  6,    // Satellite ephemeris type: 0=SGP, 2=SGP4, 6=SP
   XF_TLE_ELSETNUM   =  7,    // Element set number
   XF_TLE_INCLI      =  8,    // Orbit inclination (deg)
   XF_TLE_NODE       =  9,    // Right ascension of asending node (deg)
   XF_TLE_ECCEN      = 10,    // Eccentricity
   XF_TLE_OMEGA      = 11,    // Argument of perigee (deg)
   XF_TLE_MNANOM     = 12,    // Mean anomaly (deg)
   XF_TLE_MNMOTN     = 13,    // Mean motion (rev/day) (ephType=0: Kozai, ephType=2: Brouwer)
   XF_TLE_REVNUM     = 14,    // Revolution number at epoch 
   
   XF_TLE_NDOT       = 15,    // GP Mean motion derivative (rev/day /2)
   XF_TLE_NDOTDOT    = 16,    // GP Mean motion second derivative (rev/day**2 /6)

   XF_TLE_SP_BTERM   = 15,    // SP ballistic coefficient (m2/kg)
   XF_TLE_SP_OGPARM  = 16;    // SP outgassing parameter (km/s2)





// TleDll's function pointers
fnPtrTleInit                        TleInit;
fnPtrTleGetInfo                     TleGetInfo;
fnPtrTleLoadFile                    TleLoadFile;
fnPtrTleSaveFile                    TleSaveFile;
fnPtrTleRemoveSat                   TleRemoveSat;
fnPtrTleRemoveAllSats               TleRemoveAllSats;
fnPtrTleGetCount                    TleGetCount;
fnPtrTleGetLoaded                   TleGetLoaded;
fnPtrTleAddSatFrLines               TleAddSatFrLines;
fnPtrTleAddSatFrLinesML             TleAddSatFrLinesML;
fnPtrTleAddSatFrFieldsGP            TleAddSatFrFieldsGP;
fnPtrTleAddSatFrFieldsGP2           TleAddSatFrFieldsGP2;
fnPtrTleAddSatFrFieldsGP2ML         TleAddSatFrFieldsGP2ML;
fnPtrTleUpdateSatFrFieldsGP         TleUpdateSatFrFieldsGP;
fnPtrTleUpdateSatFrFieldsGP2        TleUpdateSatFrFieldsGP2;
fnPtrTleAddSatFrFieldsSP            TleAddSatFrFieldsSP;
fnPtrTleAddSatFrFieldsSPML          TleAddSatFrFieldsSPML;
fnPtrTleUpdateSatFrFieldsSP         TleUpdateSatFrFieldsSP;
fnPtrTleSetField                    TleSetField;
fnPtrTleGetField                    TleGetField;
fnPtrTleGetAllFieldsGP              TleGetAllFieldsGP;
fnPtrTleGetAllFieldsGP2             TleGetAllFieldsGP2;
fnPtrTleGetAllFieldsSP              TleGetAllFieldsSP;
fnPtrTleParseGP                     TleParseGP;
fnPtrTleParseSP                     TleParseSP;
fnPtrTleGetLines                    TleGetLines;
fnPtrTleGPFieldsToLines             TleGPFieldsToLines;
fnPtrTleSPFieldsToLines             TleSPFieldsToLines;
fnPtrTleGetSatKey                   TleGetSatKey;
fnPtrTleGetSatKeyML                 TleGetSatKeyML;
fnPtrTleFieldsToSatKey              TleFieldsToSatKey;
fnPtrTleFieldsToSatKeyML            TleFieldsToSatKeyML;



void LoadTleDll(const char* libPath);
void FreeTleDll();




#endif
// ========================= End of auto generated code ==========================
